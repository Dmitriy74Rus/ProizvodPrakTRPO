﻿using LesoparkKurortKokorin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для CustomerСhoiceWindow.xaml
    /// </summary>
    public partial class CustomerСhoiceWindow : Window
    {
        is1_25_kokorinds_Kurort_LesoparkEntities db = new is1_25_kokorinds_Kurort_LesoparkEntities();
        public CustomerСhoiceWindow()
        {
            InitializeComponent();
            UpdateListViewClient();
        }

        void UpdateListViewClient()
        {
            List<Client> clients = App.db.Client.ToList();
            if (TextBox_Search.Text.Length > 1)
            {
                List<Client> sortTextBoxSearch = new List<Client>();
                sortTextBoxSearch.Clear();
                var searchText = TextBox_Search.Text.ToLower();
                foreach (var client in db.Client)
                {
                    if (client.id_Client_code == client.id_Client_code)
                    {
                        sortTextBoxSearch = db.Client.Where(x => x.Surname.ToString().
                        ToLower().Contains(searchText) || x.Name.ToString().ToLower()
                        .Contains(searchText) || x.Patronomyc.ToString().ToLower()
                        .Contains(searchText) || x.Birthday.ToString().ToLower()
                        .Contains(searchText) || x.Passport.ToString().ToLower()
                        .Contains(searchText)).ToList();
                    }
                }
                clients = sortTextBoxSearch;
            }
            ListView_Clients.ItemsSource = clients;
        }

        private void TextBox_Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateListViewClient();
        }

        private void Button_AddClient_Click(object sender, RoutedEventArgs e)
        {
            AddClientWindow addClientWindow = new AddClientWindow();
            addClientWindow.ShowDialog();
            UpdateListViewClient();
        }

        private void Button_Back_Click(object sender, RoutedEventArgs e)
        {
            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
            menuUsersWindows.Show();
            this.Close();
        }

        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Метод для выбора клиента
        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            if (ListView_Clients.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали клиента!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            // Получение выбранного клиента и занесение данных о полном ФИО и коде клиента в класс
            Client client = ListView_Clients.SelectedItem as Client;
            Information.selectClient = $"{client.Surname} {client.Name} {client.Patronomyc}";
            Information.selectClientID = client.id_Client_code;
            AddOrderWindow addOrderWindow = new AddOrderWindow(client.id_Client_code);
            addOrderWindow.Show();
            this.Close();
        }
    }
}
