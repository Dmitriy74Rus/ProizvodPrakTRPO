﻿using LesoparkKurortKokorin.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для AddClientWindow.xaml
    /// </summary>
    public partial class AddClientWindow : Window
    {
        is1_25_kokorinds_Kurort_LesoparkEntities db = new is1_25_kokorinds_Kurort_LesoparkEntities();
        public AddClientWindow()
        {
            InitializeComponent();
            ComboBox_City.ItemsSource = App.db.City.ToList();
            ComboBox_Street.ItemsSource = App.db.Street.ToList();
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_AddClient_Click(object sender, RoutedEventArgs e)
        {
            if (!Check())
            {
                return;
            }
            Client client = new Client();
            client.Surname = Surname.Text;
            client.Name = Name.Text;
            client.Patronomyc = Patronomyc.Text;
            client.Birthday = DatePicker.SelectedDate.Value;
            client.Passport = Passport.Text;
            client.PostalСode = long.Parse(PostalCode.Text);
            client.id_City = (int)ComboBox_City.SelectedValue;
            client.id_Street = (int)ComboBox_Street.SelectedValue;
            client.House = long.Parse(House.Text);
            client.Flat = long.Parse(Flat.Text);
            client.Email = Email.Text;
            client.Password = Password.Text;
            App.db.Client.Add(client);
            App.db.SaveChanges();
            MessageBox.Show("Клиент был успешно добавлен!", "Внимание", MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
            this.Close();
        }

        bool Check()
        {
            if(Surname.Text == "")
            {
                MessageBox.Show("Заполните поле фамилия!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (Name.Text == "")
            {
                MessageBox.Show("Заполните поле имя!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (Patronomyc.Text == "")
            {
                MessageBox.Show("Заполните поле отчество!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (DatePicker.Text == "")
            {
                MessageBox.Show("Вы не выбрали дату рождения!", "Внимание", MessageBoxButton.OK, 
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (!DateTime.TryParse(DatePicker.Text, out DateTime a))
            {
                MessageBox.Show("Вы неправильно выбрали или написали дату! Пример: 12.12.2024", "Внимание", 
                    MessageBoxButton.OK, MessageBoxImage.Asterisk);
                return false;
            }
            if(Passport.Text == "")
            {
                MessageBox.Show("Заполните поле паспорт!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(!long.TryParse(Passport.Text, out long b))
            {
                MessageBox.Show("Поле паспорт было заполнено некорректно!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (Passport.Text.Length != 10)
            {
                MessageBox.Show("Проверьте правильно ли заполнен паспорт, он состоит из номера и серии! Пример: 2424123456",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                return false;
            }
            if(PostalCode.Text == "")
            {
                MessageBox.Show("Заполните поле почтовый индекс!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(!long.TryParse(PostalCode.Text, out long c))
            {
                MessageBox.Show("Поле почтовый индекс было заполнено некорректно!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(PostalCode.Text.Length > 6)
            {
                MessageBox.Show("Проверьте правильно ли заполнен паспорт, он состоит из 6 цифр! Пример: 421242",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                return false;
            }
            if(ComboBox_City.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали город!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(ComboBox_Street.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали улицу!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(House.Text == "")
            {
                MessageBox.Show("Заполните поле дом!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if(!long.TryParse(House.Text, out long d))
            {
                MessageBox.Show("Поле дом было заполнено некорректно!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (Flat.Text == "")
            {
                MessageBox.Show("Заполните поле квартира!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (!long.TryParse(House.Text, out long g))
            {
                MessageBox.Show("Поле квартира было заполнено некорректно!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(pattern);
            MatchCollection passN1 = regex.Matches(Email.Text);
            if (passN1.Count <= 0)
            {
                MessageBox.Show("Введите корректный email! Например: dmitriy@mail.ru", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }
    }
}
