﻿using LesoparkKurortKokorin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для HistroryLoginWindow.xaml
    /// </summary>
    public partial class HistroryLoginWindow : Window
    {
        is1_25_kokorinds_Kurort_LesoparkEntities db = new is1_25_kokorinds_Kurort_LesoparkEntities();
        public HistroryLoginWindow()
        {
            InitializeComponent();
            UpdateListView();
        }

        void UpdateListView()
        {
            List<HistoryLogin> historyLogin = App.db.HistoryLogin.ToList();
            // Проверка на пустое поле поиска
            if(TextBox_Search.Text.Length > 1)
            {
                List<HistoryLogin> sortTextBoxSearch = new List<HistoryLogin>();
                sortTextBoxSearch.Clear();
                var searchText = TextBox_Search.Text.ToLower();
                // Проверка данных в таблице и поиск необходимых строчек
                foreach(var history in db.HistoryLogin)
                {
                    if(history.id_HistoryLogin == history.id_HistoryLogin)
                    {
                        sortTextBoxSearch = db.HistoryLogin.Where(x => x.Employee.Login.ToString().
                        ToLower().Contains(searchText) || x.DateAndTimeOfEntry.ToString().ToLower()
                        .Contains(searchText)).ToList();
                    }
                }
                historyLogin = sortTextBoxSearch;
            }
            // Вывод в таблицу информации о истории входа
            ListView_HistoryJoin.ItemsSource = historyLogin;
        }
        // Метод моментального обновления введенных данных в поле поиска
        private void TextBox_Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TextBox_Search.Text.Length > 0)
            {
                UpdateListView();
            }
            else if (TextBox_Search.Text.Length == 0)
            {
                TextBox_Search.Text = null;
            }
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Back_Click(object sender, RoutedEventArgs e)
        {
            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
            menuUsersWindows.Show();
            this.Close();
        }

    }
}
