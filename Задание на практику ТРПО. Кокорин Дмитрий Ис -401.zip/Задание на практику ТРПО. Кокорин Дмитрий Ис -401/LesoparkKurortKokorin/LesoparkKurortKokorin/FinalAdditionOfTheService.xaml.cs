﻿using LesoparkKurortKokorin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для FinalAdditionOfTheService.xaml
    /// </summary>
    public partial class FinalAdditionOfTheService : Window
    {
        Client curClient;
        List<int> idServ;
        public FinalAdditionOfTheService(int code, List<int> services)
        {
            InitializeComponent();
            //Вывод итоговых данных по созданию заказа
            idServ = services;
            curClient = App.db.Client.Where(x => x.id_Client_code == code).FirstOrDefault();
            ClientFullname.Text = null;
            ClientFullname.Text = Information.selectClient;
            List<Service> selserv = new List<Service>();
            foreach (var item in services)
            {
                Service service = App.db.Service.Where(x => x.id_Service == item).FirstOrDefault();
                selserv.Add(service);
            }
            ListView_Service.ItemsSource = selserv;
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            // Обращение к методу для проверки введенных данных
            if (!Check())
            {
                return;
            }
            // Метод добавления нового заказа
            int Times = int.Parse(TextBox_TimeRentable.Text);
            Order order = new Order();
            order.RentalTime = Times;
            order.CreateDateOrder = DateTime.Now.Date;
            order.id_Code_client = curClient.id_Client_code;
            order.id_Status = ((Status)App.db.Status.Where(x => x.Name == "Новая")
                .FirstOrDefault()).id_Status;
            order.ClosedDate = null;
            order.OrderTime = TimeSpan.Parse(DateTime.Now.TimeOfDay.ToString());
            order.OrderCode = $"{curClient.id_Client_code}/{order.CreateDateOrder}";
            App.db.Order.Add(order); // Добавление данных о заказе
            App.db.SaveChanges(); // Сохранение данных о заказе в базу данных
            order = App.db.Order.Where(x => x.OrderCode == order.OrderCode).FirstOrDefault();
            // Метод добавление услуг заказа
            foreach (var item in idServ)
            {
               // Добавление данных о всех выбранных услугах к одному заказу
               App.db.ServiceOrder.Add(new ServiceOrder()
               { id_Order = order.id_Order, id_Service = item });
            }
            App.db.SaveChanges(); // Сохранение данных о заказе и выбранных услугах в базу данных
            MessageBox.Show("Заказ был успешно оформлен!", "Успешно", MessageBoxButton.OK, 
                MessageBoxImage.Asterisk);
            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
            menuUsersWindows.Show();
            this.Close();
        }

        bool Check()
        {
            if (TextBox_TimeRentable.Text == "")
            {
                MessageBox.Show("Заполните поле время проката!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                return false;
            }
            if (!int.TryParse(TextBox_TimeRentable.Text, out int a))
            {
                MessageBox.Show("Введите минуты корректно!", "Ошибка", MessageBoxButton.OK, 
                    MessageBoxImage.Error);
                return false;
            }
            return true;
        }

            private void Button_Back_Click(object sender, RoutedEventArgs e)
        {
            AddOrderWindow addOrderWindow = new AddOrderWindow(Information.selectClientID);
            addOrderWindow.Show();
            this.Close();
        }

        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
