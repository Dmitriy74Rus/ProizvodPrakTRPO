﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LesoparkKurortKokorin
{
    internal class Information
    {
        public static int? idUser;

        public static string Surname;

        public static string Name;

        public static string Patronomyc;

        public static string Login;

        public static string Role;

        public static string selectClient;

        public static int selectClientID;

    }
}
