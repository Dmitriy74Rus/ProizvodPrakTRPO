﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для AddOrderWindow.xaml
    /// </summary>
    public partial class AddOrderWindow : Window
    {
        List<ItemService> itemServices;
        int code;
        public AddOrderWindow(int clientCode)
        {
            InitializeComponent();
            code = clientCode;
            itemServices = new List<ItemService>();
            // занесение услуг в лист, который использует специальный класс для использования элемента CheckBox
            foreach (var item in App.db.Service)
            {
                itemServices.Add(new ItemService() { Service = item });
            }
            serviceList.ItemsSource = itemServices;
        }

        private void TextBox_Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = TextBox_Search.Text.ToLower();
            List<ItemService> itemServicesSearch = new List<ItemService>();
            foreach (var item in itemServices)
            {
                if (item.Service.Name.ToLower().Contains(search))
                    itemServicesSearch.Add(item);
            }
            serviceList.ItemsSource = itemServicesSearch;
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            List<int> services = new List<int>();
            foreach (var item in itemServices)
            {
                if (item.isChecked)
                    services.Add(item.Service.id_Service);
            }
            FinalAdditionOfTheService service = new FinalAdditionOfTheService(code, services);
            if (services.Count == 0)
            {
                MessageBox.Show("Выберите одну услугу и более!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            service.Show();
            this.Close();
        }

        private void Button_Back_Click(object sender, RoutedEventArgs e)
        {
            Information.selectClient = null;
            CustomerСhoiceWindow customerСhoiceWindow = new CustomerСhoiceWindow();
            customerСhoiceWindow.Show();
            this.Close();
        }

        // Метод сворачивания окна
        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        // Метод закрытия окна
        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
