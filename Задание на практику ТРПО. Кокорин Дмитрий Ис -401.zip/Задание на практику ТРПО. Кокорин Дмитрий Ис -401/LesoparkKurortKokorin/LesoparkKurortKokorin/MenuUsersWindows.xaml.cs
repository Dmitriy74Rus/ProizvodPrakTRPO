﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для MenuUsersWindows.xaml
    /// </summary>
    public partial class MenuUsersWindows : Window
    {
        public MenuUsersWindows()
        {
            InitializeComponent();
            // Вывод текущего пользователя в системе
            if(Information.Surname == "Беляева")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Беляева.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Иванов")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Иванов.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Игнатов")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Игнатов.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Миронов")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Миронов.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Петров")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Петров.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Смирнова")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Смирнова.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Стрелков")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Стрелков.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Федоров")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Федоров.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Хохлов")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Хохлов.jpeg", UriKind.Absolute));
            }
            if (Information.Surname == "Ширяев")
            {
                imageUsers.Source = new BitmapImage(new Uri("D:\\Задание на практику ТРПО\\" +
                    "Задание на практику ТРПО\\LesoparkKurortKokorin\\LesoparkKurortKokorin\\" +
                    "EmployeeImage\\Ширяев.jpeg", UriKind.Absolute));
            }
            Surname.Text = Information.Surname;
            Name.Text = Information.Name;
            Patronomyc.Text = Information.Patronomyc;
            Role.Text = Information.Role;
            // Оторбражение функционала в зависимости от роли
            if(Role.Text == "Продавец")
            {
                MenuEmployee.Visibility = Visibility.Visible;
                MenuShiftSupervisor.Visibility = Visibility.Hidden;
                MenuAdministrator.Visibility = Visibility.Hidden;
            }
            if(Role.Text == "Старший смены")
            {
                MenuEmployee.Visibility = Visibility.Hidden;
                MenuShiftSupervisor.Visibility = Visibility.Visible;
                MenuAdministrator.Visibility = Visibility.Hidden;
            }
            if (Role.Text == "Администратор")
            {
                MenuEmployee.Visibility = Visibility.Hidden;
                MenuShiftSupervisor.Visibility = Visibility.Hidden;
                MenuAdministrator.Visibility = Visibility.Visible;
            }
        }

        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CreateAnOrder_Click(object sender, RoutedEventArgs e)
        {
            CustomerСhoiceWindow customerСhoiceWindow = new CustomerСhoiceWindow();
            customerСhoiceWindow.Show();
            this.Close();
        }

        private void AcceptTheProduct_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Данная функция пока недоступна!", "Внимание", MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
            return;
        }

        private void HistoryInput_Click(object sender, RoutedEventArgs e)
        {
            HistroryLoginWindow histroryLoginWindow = new HistroryLoginWindow();
            histroryLoginWindow.Show();
            this.Close();
        }

        private void TrackingAllOrders_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Данная функция пока недоступна!", "Внимание", MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
            return;
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Information.Surname = null;
            Information.Name = null;
            Information.Patronomyc = null;
            Information.Role = null;
            Information.idUser = null;
            Information.Login = null;
            Information.selectClient = null;
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
