﻿using LesoparkKurortKokorin.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int countCaptcha;
        private int secondsLeft = 10;
        private DispatcherTimer timer;
        public MainWindow()
        {
            InitializeComponent();
        }

        int CaptchaWrong;
        private void Button_EnterCaptcha_Click(object sender, RoutedEventArgs e)
        {
            if (AnswerBox.Text == CaptchaAnswer)
            {
                MessageBox.Show("Каптча введена правильно!", "Внимание", MessageBoxButton.OK,
                    MessageBoxImage.Asterisk);
                TextBox_Login.IsReadOnly = false;
                TextBox_Password.IsReadOnly = false;
                Button_EnterJoin.IsEnabled = true;
                TimeBlock.Visibility = Visibility.Hidden;
                CaptchaInput.Visibility = Visibility.Hidden;
                Captcha.Height = new GridLength(0);
                CaptchaWrong = 0;
                countCaptcha = 0;
            }
            else
            {
                CaptchaWrong = CaptchaWrong + 1;
                if (CaptchaWrong == 1)
                {
                    MessageBox.Show("Каптча введена неправильно! Попытка 1 из 3", "Внимание", MessageBoxButton.OK,
                        MessageBoxImage.Asterisk);
                    Captcha_Generate();
                }
                else if (CaptchaWrong == 2)
                {
                    MessageBox.Show("Каптча введена неправильно! Попытка 2 из 3", "Внимание", MessageBoxButton.OK,
                        MessageBoxImage.Asterisk);
                    Captcha_Generate();
                }
                else if (CaptchaWrong == 3)
                {
                    MessageBox.Show("Каптча введена неправильно, вы заблокированы на 10 секунд! Попытка 3 из 3",
                        "Внимание", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    Captcha_Generate();
                    TimeBlock.Visibility = Visibility.Visible;
                    CaptchaInput.Visibility = Visibility.Hidden;
                    TextBox_Login.IsReadOnly = true;
                    TextBox_Password.IsReadOnly = true;
                    Button_EnterJoin.IsEnabled = false;
                    timer = new DispatcherTimer();
                    timer.Interval = TimeSpan.FromSeconds(1);
                    timer.Start();
                    timer.Tick += Timer_Tick;
                }
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            secondsLeft--;
            Lable_TimeBlock.Content = secondsLeft.ToString();

            if (secondsLeft == 0)
            {
                timer.Stop();
                TextBox_Login.IsReadOnly = false;
                TextBox_Password.IsReadOnly = false;
                Button_EnterJoin.IsEnabled = true;
                TimeBlock.Visibility = Visibility.Hidden;
                CaptchaInput.Visibility = Visibility.Hidden;
                Captcha.Height = new GridLength(0);
                CaptchaWrong = 0;
                countCaptcha = 0;
                // Выполните ваше действие после окончания отсчета времени
                MessageBox.Show("Вы снова можете ввести данные!", "Внимание", MessageBoxButton.OK, 
                    MessageBoxImage.Asterisk);
                Lable_TimeBlock.Content = null;
                secondsLeft = 10;
            }
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_RollUp_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        // Метод проверки при входе в систему
        private void Button_EnterJoin_Click(object sender, RoutedEventArgs e)
        {
            string login = TextBox_Login.Text;
            string password = TextBox_Password.Text;
            if (login == "")
            {
                if (password == "")
                {
                    MessageBox.Show("Вы не заполнили поля: Логин и Пароль", "Внимание", MessageBoxButton.OK, 
                        MessageBoxImage.Error);
                    return;
                }
                MessageBox.Show("Вы не заполнили поле: Логин", "Внимание", MessageBoxButton.OK, 
                    MessageBoxImage.Error);
                return;
            }
            else if (password == "")
            {
                MessageBox.Show("Вы не заполнили поле: Пароль", "Внимание", MessageBoxButton.OK, 
                    MessageBoxImage.Error);
                return;
            }
            is1_25_kokorinds_Kurort_LesoparkEntities db = new is1_25_kokorinds_Kurort_LesoparkEntities();
            foreach (var employee in App.db.Employee)
            {
                if (employee.id_Role == 1)
                {
                    // Проверка на введенный логин и пароль в системе
                    if (employee.Login == login)
                    {
                        if (employee.Password == password)
                        {
                            // Запись в историю входа пользователя который авторизовался
                            HistoryLogin historyLogin = new HistoryLogin();
                            historyLogin.id_Employee = employee.id_Employee;
                            historyLogin.id_TypeOfEntry = 2;
                            historyLogin.DateAndTimeOfEntry = DateTime.Now.ToString();
                            db.HistoryLogin.Add(historyLogin);
                            db.SaveChanges();
                            Information.idUser = employee.id_Employee;
                            Information.Surname = employee.Surname;
                            Information.Name = employee.Name;
                            Information.Patronomyc = employee.Patronomyc;
                            Information.Login = employee.Login;
                            Information.Role = employee.Role.Name;
                            MessageBox.Show("Вы успешно вошли в систему!", "Внимание", MessageBoxButton.OK,
                                MessageBoxImage.Asterisk);
                            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
                            menuUsersWindows.Show();
                            this.Close();
                            return;
                        }
                        // Запись в историю входа пользователя который провалил авторизацию
                        HistoryLogin historyLoginn = new HistoryLogin();
                        TypeOfEntry entry = new TypeOfEntry();
                        historyLoginn.id_Employee = employee.id_Employee;
                        historyLoginn.id_TypeOfEntry = 1;
                        historyLoginn.DateAndTimeOfEntry = DateTime.Now.ToString();
                        db.HistoryLogin.Add(historyLoginn);
                        db.SaveChanges();
                        MessageBox.Show("Неверный пароль!", "Ошибка", MessageBoxButton.OK, 
                            MessageBoxImage.Error);
                        countCaptcha = countCaptcha + 1;
                        // При неправильном вводе пароля более 3 раз появляется капча
                        if(countCaptcha > 2)
                        {
                            Captcha.Height = new GridLength(180);
                            CaptchaInput.Visibility = Visibility.Visible;
                            TextBox_Login.IsReadOnly = true;
                            TextBox_Password.IsReadOnly = true;
                            Button_EnterJoin.IsEnabled = false;
                            Captcha_Generate();
                        }
                        return;
                    }
                }
                if (employee.id_Role == 2)
                {
                    if (employee.Login == login)
                    {
                        if (employee.Password == password)
                        {
                            HistoryLogin historyLogin = new HistoryLogin();
                            historyLogin.id_Employee = employee.id_Employee;
                            historyLogin.id_TypeOfEntry = 2;
                            historyLogin.DateAndTimeOfEntry = DateTime.Now.ToString();
                            db.HistoryLogin.Add(historyLogin);
                            db.SaveChanges();
                            Information.idUser = employee.id_Employee;
                            Information.Surname = employee.Surname;
                            Information.Name = employee.Name;
                            Information.Patronomyc = employee.Patronomyc;
                            Information.Login = employee.Login;
                            Information.Role = employee.Role.Name;
                            MessageBox.Show("Вы успешно вошли в систему!", "Внимание", MessageBoxButton.OK,
                                MessageBoxImage.Asterisk);
                            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
                            menuUsersWindows.Show();
                            this.Close();
                            return;
                        }
                        HistoryLogin historyLoginn = new HistoryLogin();
                        TypeOfEntry entry = new TypeOfEntry();
                        historyLoginn.id_Employee = employee.id_Employee;
                        historyLoginn.id_TypeOfEntry = 1;
                        historyLoginn.DateAndTimeOfEntry = DateTime.Now.ToString();
                        db.HistoryLogin.Add(historyLoginn);
                        db.SaveChanges();
                        MessageBox.Show("Неверный пароль!", "Ошибка", MessageBoxButton.OK,
                            MessageBoxImage.Error);
                        countCaptcha = countCaptcha + 1;
                        if (countCaptcha > 2)
                        {
                            Captcha.Height = new GridLength(180);
                            CaptchaInput.Visibility = Visibility.Visible;
                            TextBox_Login.IsReadOnly = true;
                            TextBox_Password.IsReadOnly = true;
                            Button_EnterJoin.IsEnabled = false;
                            Captcha_Generate();
                        }
                        return;
                    }
                }
                if (employee.id_Role == 3)
                {
                    if (employee.Login == login)
                    {
                        if(employee.Password == password)
                        {
                            HistoryLogin historyLogin = new HistoryLogin();
                            historyLogin.id_Employee = employee.id_Employee;
                            historyLogin.id_TypeOfEntry = 2;
                            historyLogin.DateAndTimeOfEntry = DateTime.Now.ToString();
                            db.HistoryLogin.Add(historyLogin);
                            db.SaveChanges();
                            Information.idUser = employee.id_Employee;
                            Information.Surname = employee.Surname;
                            Information.Name = employee.Name;
                            Information.Patronomyc = employee.Patronomyc;
                            Information.Login = employee.Login;
                            Information.Role = employee.Role.Name;
                            MessageBox.Show("Вы успешно вошли в систему!", "Внимание", MessageBoxButton.OK,
                                MessageBoxImage.Asterisk);
                            MenuUsersWindows menuUsersWindows = new MenuUsersWindows();
                            menuUsersWindows.Show();
                            this.Close();
                            return;
                        }
                        HistoryLogin historyLoginn = new HistoryLogin();
                        TypeOfEntry entry = new TypeOfEntry();
                        historyLoginn.id_Employee = employee.id_Employee;
                        historyLoginn.id_TypeOfEntry = 1;
                        historyLoginn.DateAndTimeOfEntry = DateTime.Now.ToString();
                        db.HistoryLogin.Add(historyLoginn);
                        db.SaveChanges();
                        MessageBox.Show("Неверный пароль!", "Ошибка", MessageBoxButton.OK,
                            MessageBoxImage.Error);
                        countCaptcha = countCaptcha + 1;
                        if (countCaptcha > 2)
                        {
                            Captcha.Height = new GridLength(180);
                            CaptchaInput.Visibility = Visibility.Visible;
                            TextBox_Login.IsReadOnly = true;
                            TextBox_Password.IsReadOnly = true;
                            Button_EnterJoin.IsEnabled = false;
                            Captcha_Generate();
                        }
                        return;
                    }
                }
            }
            MessageBox.Show("Пользователя с таким логином нет!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        char[] allowedSigns =
                    ("QWERTYUIOPASDFGHJKLZXCVBNM1234567890qwe" +
                    "rtyuiopasdfghjklzxcvbnm1234567890").ToCharArray();

        private string CaptchaAnswer { get; set; }

        private void Captcha_Generate()
        {
            Signs.Children.Clear();
            Signss.Children.Clear();
            AnswerBox.Text = "";
            CaptchaAnswer = "";
            Random rand = new Random();
            Random rnd = new Random();
            for (int i = 0; i < 250; i++)
            {
                Ellipse ellipse = new Ellipse();
                int r = rnd.Next(3, 5);
                ellipse.Height = r; ellipse.Width = r;
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), 
                    (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                ellipse.Fill = brus;
                Canvas.SetLeft(ellipse, rnd.Next(140));
                Canvas.SetTop(ellipse, rnd.Next(30));
                Signs.Children.Add(ellipse);
            }
            for (int i = 0; i < 2; i++)
            {
                Line line = new Line();
                line.X1 = rnd.Next(0, 80);
                line.Y1 = rnd.Next(0, 20);
                line.X2 = rnd.Next(70, 110);
                line.Y2 = rnd.Next(10, 30);
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), 
                    (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                line.Stroke = brus;
                line.StrokeThickness = 3;
                Signs.Children.Add(line);
            }
            int power = 6; // Кол во символов в каптче
            for (int i = 0; i < power; i++)
            {
                char sign =
                    // Вытягиваем рандомный символ из массива
                    allowedSigns[rand.Next(0, allowedSigns.Length)];
                CaptchaAnswer += sign; // Записываем в ответ каптчи
                var tg = Sign_Wrap();
                // Создаем текст блок
                TextBlock tb = new TextBlock()
                {
                    Text = sign.ToString(),
                    FontSize = 26,
                };
                // Применяем искажение
                tb.RenderTransform = tg;
                // Отображаем
                Signss.Children.Add(tb);
            }
        }

        // Создание искревлений
        private TransformGroup Sign_Wrap()
        {
            // Группа искажений
            TransformGroup tg = new TransformGroup();
            // Поворот, перекос и отклонение
            RotateTransform rt = new RotateTransform();
            SkewTransform st = new SkewTransform();
            TranslateTransform lt = new TranslateTransform();

            Random rand = new Random();

            rt.Angle = rand.Next(-34, 24);
            st.AngleX = rand.Next(-12, 20);
            st.AngleY = rand.Next(-34, 22);
            lt.X = rand.Next(5, 30);
            lt.Y = rand.Next(2, 12);

            // Добавляем в группу
            tg.Children.Add(rt);
            tg.Children.Add(st);
            tg.Children.Add(lt);

            return tg;
        }

        private void Reload_Click(object sender, RoutedEventArgs e)
        {
            Captcha_Generate();
        }
    }
}
