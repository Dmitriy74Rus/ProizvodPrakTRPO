﻿using LesoparkKurortKokorin.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace LesoparkKurortKokorin
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static is1_25_kokorinds_Kurort_LesoparkEntities db = new is1_25_kokorinds_Kurort_LesoparkEntities();
    }
}
