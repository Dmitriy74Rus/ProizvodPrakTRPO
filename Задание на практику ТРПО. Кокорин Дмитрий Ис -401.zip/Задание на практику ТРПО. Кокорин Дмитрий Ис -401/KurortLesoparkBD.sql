create database is1_25_kokorinds_Kurort_Lesopark
use is1_25_kokorinds_Kurort_Lesopark

create table [Role]
(
id_Role int primary key identity,
[Name] nvarchar(50) not null,
)

create table Employee
(
id_Employee int primary key identity,
Surname nvarchar(50) not null,
[Name] nvarchar(50) not null,
Patronomyc nvarchar(50) not null,
[Login] nvarchar(50) not null,
[Password] nvarchar(50) not null,
id_Role int not null,
foreign key (id_Role) references [Role](id_Role)
)

create table TypeOfEntry
(
id_TypeOfEntry int primary key identity,
[Name] nvarchar(50) not null,
)

create table HistoryLogin
(
id_HistoryLogin int primary key identity,
id_Employee int not null,
DateAndTimeOfEntry nvarchar(50) not null,
id_TypeOfEntry int not null,
foreign key (id_Employee) references [Employee](id_Employee),
foreign key (id_TypeOfEntry) references TypeOfEntry(id_TypeOfEntry)
)

create table City
(
id_City int primary key identity,
[Name] nvarchar(100) not null,
)

create table Street
(
id_Street int primary key identity,
[Name] nvarchar(100) not null,
)

create table Client
(
id_Client_code int primary key identity,
Surname nvarchar(50) not null,
[Name] nvarchar(50) not null,
Patronomyc nvarchar(50) not null,
Passport nvarchar(11) not null,
Birthday date not null,
Postal�ode bigint not null,
House bigint not null,
Flat bigint not null,
id_City int not null,
id_Street int not null,
Email nvarchar(50) not null,
[Password] nvarchar(50) not null,
foreign key (id_City) references City(id_City),
foreign key (id_Street) references Street(id_Street)
)

create table [Status]
(
id_Status int primary key identity,
[Name] nvarchar(50) not null,
)

create table [Order]
(
id_Order int primary key identity,
OrderCode nvarchar(50) not null,
CreateDateOrder date not null,
OrderTime time not null,
id_Code_client int not null,
id_Status int not null,
ClosedDate date,
RentalTime int not null,
foreign key (id_Status) references [Status](id_Status),
foreign key (id_Code_client) references Client(id_Client_code)
)

create table [Service]
(
id_Service int primary key identity,
[Name] nvarchar(100) not null,
ServiceCode nvarchar(50) not null,
Cost money not null,
)

create table ServiceOrder
(
id_ServiceOrder int primary key identity,
id_Order int not null,
id_Service int not null,
foreign key (id_Order) references [Order](id_Order),
foreign key (id_Service) references [Service](id_Service)
)